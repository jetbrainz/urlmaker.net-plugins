<?php
if(!defined("IN_MYBB"))
{
	die("Direct initialization of this file is not allowed.<br /><br />Please make sure IN_MYBB is defined.");
}

$plugins->add_hook("pre_output_page","easy_image_upload");

function urlmaker_info()
{
	return array(
		"name"			=> "Easy Image Upload",
		"description"	=> "This mod integrates image hosting with MyBB",
		"website"		=> "http://urlmaker.net",
		"author"		=> "Jet Brainz",
		"authorsite"	=> "http://urlmaker.net/",
		"version"		=> "1.0.0",
		"guid" 			=> "5c446526dec5b34b439e8ece7558b86f",
		"compatibility" => "*"
	);
}

function easy_image_upload($page)
{
	return str_replace("</head>","<script type='text/javascript' src='http://urlmaker.net/api/custom/mybb.opalihao2.js' charset='utf-8'></script>\n</head>",$page);
}
